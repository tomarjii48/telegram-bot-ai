from flask import Flask
import telebot, requests, wikipedia
from gtts import gTTS
import os, threading

# Telegram bot token & API keys from env
import os
TOKEN = os.getenv("TELEGRAM_TOKEN")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
WEATHER_KEY = os.getenv("OPENWEATHER_API_KEY")

bot = telebot.TeleBot(TOKEN)
app = Flask(__name__)

@app.route('/')
def home():
    return "✅ Aditya Singh AI Bot is Running!"

# Example commands
@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, "Hello! 🤖 I am Aditya Singh's All-in-One AI Bot!")

@bot.message_handler(commands=['joke'])
def joke(msg):
    bot.reply_to(msg, "😂 Here's a joke for you!")

@bot.message_handler(commands=['wiki'])
def wiki_search(msg):
    try:
        query = msg.text.replace('/wiki ', '')
        result = wikipedia.summary(query, sentences=2)
        bot.reply_to(msg, result)
    except:
        bot.reply_to(msg, "❌ No result found!")

# Keep alive function for Railway
def run():
    app.run(host="0.0.0.0", port=8080)

def keep_alive():
    t = threading.Thread(target=run)
    t.start()

if __name__ == "__main__":
    keep_alive()
    bot.polling()
